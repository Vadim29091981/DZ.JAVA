package org.example.engine1;

/*Ваш класс Car зависит от интерфейса Engine.
Создайте несколько реализаций интерфейса Engin(например, GasEngine и ElectricEngine).
Аннотируйте их с помощью @Component с названием бинов,
чтобы явно указать, какой двигатель должен быть использован в каждом случае.
Затем внедрите зависимость двигателя в класс Car с помощью @Autowired и @Qualifier,
чтобы можно было выбрать тип двигателя во время компиляции. */

import org.example.AppConfig;
import org.example.engine1.Car;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        Car car = context.getBean(Car.class);
        car.start();
        car.stop();

        context.close();
    }
}
