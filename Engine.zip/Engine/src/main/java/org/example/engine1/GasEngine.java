package org.example.engine1;

import org.springframework.stereotype.Component;

@Component("gasEngine")
public class GasEngine implements Engine {
    @Override
    public void start() {
        System.out.println("Gas engine started");
    }

    @Override
    public void stop() {
        System.out.println("Gas engine stopped");
    }
}


