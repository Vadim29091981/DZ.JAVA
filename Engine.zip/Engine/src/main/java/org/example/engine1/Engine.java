package org.example.engine1;

public interface Engine {
    void start();
    void stop();
}
