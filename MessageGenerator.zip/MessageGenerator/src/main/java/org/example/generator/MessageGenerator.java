package org.example.generator;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class MessageGenerator {
    public String generateMessage() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("2024-12-12 10:10:10");
        String timestamp = dateFormat.format(new Date());
        return "Добрый вечер не работает код, что-то нажал, горит кофе)" + timestamp;
    }
}
