package org.example.generator;
/*Создайте класс MessageGenerator,
который генерирует уникальные сообщения с временной меткой.
Каждый раз, когда бин запрашивается из контекста,
создаётся новый экземпляр MessageGenerator.
Внедрите этот бин в классы EmailSender и SmsSender.

 */
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("org.example.generator")
public class Main {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Main.class);

        EmailSender emailSender = context.getBean(EmailSender.class);
        emailSender.sendEmail();

        SmsSender smsSender = context.getBean(SmsSender.class);
        smsSender.sendSms();

        context.close();
    }
}
